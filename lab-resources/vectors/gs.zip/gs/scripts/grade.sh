#!/usr/bin/env sh

exe=lab10

# check if ".cpp" is in any of the arguments
for arg in "$@"; do
    if [[ $arg == *.cpp ]]; then
        # if so, compile the file
        g++ -Wall -std=c++11 -O0 -g3 -o $exe $arg
    fi
done

# check if --all was passed
if [[ $@ == *--all* ]]; then

    # compare the output of exe from all input files in gs/in to the corresponding output files in gs/out
    for f in gs/in/*; do
        echo "Processing $f file..."
        ./$exe <$f >out.txt
        base=$(basename $f)

        diff -y out.txt gs/out/$base >diff.txt

        # if exitcode is non-zero, then the files are different and the output should be printed
        if [[ $? -ne 0 ]]; then
            echo -e '\nYOURS                                                         SOLUTION'
            echo ----------------------------------------------------------------------------------------------------
            cat diff.txt
            rm -f diff.txt
            echo -e "\nFailed test case: $f"
            echo -e "Run the following command to test this input directly:"
            echo -e "make test CASE=$f"
            exit
        fi

        # else print pass
        if [[ $? -eq 0 ]]; then
            echo -e "Passed test case: $f\n"
        fi
    done
    rm -f diff.txt
fi

# check if --leaks was passed
if [[ $@ == *--leaks* ]]; then
    # run valgrind for each input file
    for file in gs/in/*.txt; do
        # run valgrind on the program and print the line number of the first leak
        valgrind --leak-check=full --track-origins=yes --log-file=valgrind.log --error-exitcode=1 ./$exe <"$file" >/dev/null
        error=$?

        # loop through the valgrind log file and print the line number of the first leak
        while read line; do

            if [[ $line == *"definitely lost"* || $line == *"at 0x"* || $line == *"by 0x"* ]]; then
                echo $line >>log
            fi

        done \
            <valgrind.log

        if [[ $error -eq 1 ]]; then
            cat log
            echo ""
            echo "Valgrind detected memory leaks in $file -- Make sure you're using delete[] to free *every* array!"
            rm -f log
            exit

        else
            echo "No memory leaks in $file"
            rm -f log
        fi
    done
    exit
fi

if [ "$1" == "--case" ]; then
    # compare the output of $exe from the input file in gs/in to the corresponding output file in gs/out
    echo "Processing $2 file..."
    ./$exe <$2 >out.txt
    base=$(basename $2)

    diff -y out.txt gs/out/$base >diff.txt

    # if exitcode is non-zero, then the files are different and the output should be printed
    if [[ $? -ne 0 ]]; then
        echo -e '\nYOURS                                                         SOLUTION'
        echo ----------------------------------------------------------------------------------------------------
        cat diff.txt
        echo -e "\nFailed test case: $2"
        exit
    else
        echo -e "Passed test case: $2\n"
    fi
    rm -f diff.txt
    exit
fi
