#!/bin/bash

EXIT_ON_FAIL=true
# DIFF_OUTPUT_ON_FAIL=true

SOURCE_FILE=$1
BIN_FILE=$(basename $SOURCE_FILE .cpp)

# Usage
if [[ ! -f $SOURCE_FILE ]]; then
    echo "File '$SOURCE_FILE' not found."
    echo "Usage: bash $0 <source-file>"
    exit 1
fi

# Test
for TEST in $(ls tests/in); do

    INPUT_TEST_FILE="tests/in/$TEST"
    OUTPUT_TEST_FILE="tests/out/$TEST"

    printf "$TEST: "

    if ! diff <(./$BIN_FILE <$INPUT_TEST_FILE) $OUTPUT_TEST_FILE &>/dev/null; then
        echo FAILED
        if [[ $EXIT_ON_FAIL == true ]]; then
            echo
            echo 'YOURS                                                         EXPECTED'
            diff -y <(./$BIN_FILE <$INPUT_TEST_FILE) $OUTPUT_TEST_FILE
            exit 1
        fi
    else
        echo PASSED
    fi
done
